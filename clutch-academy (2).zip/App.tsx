// FIX: Implemented the main App component with context providers and routing.
import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { LocalizationProvider } from './contexts/LocalizationContext';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import CoachDashboard from './components/CoachDashboard';
import { Role } from './types';

const AppContent: React.FC = () => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <Login />;
  }

  if (currentUser.role === Role.Admin) {
    return <AdminDashboard />;
  }

  if (currentUser.role === Role.Coach) {
    return <CoachDashboard />;
  }

  return null; // Or some fallback UI for unexpected roles
};

const App: React.FC = () => {
  return (
    <LocalizationProvider>
      <DataProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </DataProvider>
    </LocalizationProvider>
  );
};

export default App;
