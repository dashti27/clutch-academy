
export enum Role {
  Admin,
  Coach,
}

export interface User {
  id: string;
  username: string;
  password: string;
  role: Role;
  branchId?: string;
}

export interface Branch {
  id: string;
  name: string;
}

export enum SubscriptionStatus {
  Active = 'Active',
  Expired = 'Expired',
}

export interface Subscriber {
  id:string;
  name: string;
  phone: string;
  subscriptionEndDate: string;
  branchId?: string;
}

export interface AttendanceRecord {
  id: string;
  subscriberId: string;
  date: string; // YYYY-MM-DD
}

export interface CoachAttendanceRecord {
  id: string;
  coachId: string;
  date: string; // YYYY-MM-DD
}