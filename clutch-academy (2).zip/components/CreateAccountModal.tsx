
import React, { useState } from 'react';
import { Role } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';

interface CreateAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CreateAccountModal: React.FC<CreateAccountModalProps> = ({ isOpen, onClose }) => {
  const { addUser, users } = useData();
  const { t } = useLocalization();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const resetState = () => {
    setUsername('');
    setPassword('');
    setError('');
    setSuccessMessage('');
  };

  const handleClose = () => {
    resetState();
    onClose();
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
        setError('Username already exists.');
        return;
    }

    if (!username || !password) {
        setError('Username and password are required.');
        return;
    };

    addUser({ username, password, role: Role.Coach });
    setSuccessMessage(t('accountCreatedSuccess'));
    setTimeout(() => {
        handleClose();
    }, 3000); // Close modal after 3 seconds
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-brand-gray p-8 rounded-lg shadow-2xl w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-white mb-6 text-center">{t('createAccount')}</h2>
        {successMessage ? (
             <p className="text-center text-green-400">{successMessage}</p>
        ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-gray-300 mb-2">{t('username')}</label>
                    <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
                </div>
                <div>
                    <label className="block text-gray-300 mb-2">{t('password')}</label>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
                </div>
                 {error && <p className="text-red-500 text-xs italic text-center">{error}</p>}
                <div className="flex justify-end gap-4 pt-4">
                    <button type="button" onClick={handleClose} className="bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500">{t('cancel')}</button>
                    <button type="submit" className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400">{t('createAccount')}</button>
                </div>
            </form>
        )}
      </div>
    </div>
  );
};

export default CreateAccountModal;
