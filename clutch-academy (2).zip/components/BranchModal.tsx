
import React, { useState, useEffect } from 'react';
import { Branch } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';

interface BranchModalProps {
  isOpen: boolean;
  onClose: () => void;
  branchToEdit: Branch | null;
}

const BranchModal: React.FC<BranchModalProps> = ({ isOpen, onClose, branchToEdit }) => {
  const { addBranch, updateBranch } = useData();
  const { t } = useLocalization();
  const [name, setName] = useState('');

  useEffect(() => {
    if (branchToEdit) {
      setName(branchToEdit.name);
    } else {
      setName('');
    }
  }, [branchToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    if (branchToEdit) {
      updateBranch({ ...branchToEdit, name });
    } else {
      addBranch({ name });
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-brand-gray p-8 rounded-lg shadow-2xl w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-white mb-6">{branchToEdit ? t('editBranch') : t('addBranch')}</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">{t('branchName')}</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
          <div className="flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500">{t('cancel')}</button>
            <button type="submit" className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400">{t('save')}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BranchModal;
