
import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import { translations } from '../lib/localization';
import { Role } from '../types';

interface CoachAttendanceReportProps {
  onClose: () => void;
}

const CoachAttendanceReport: React.FC<CoachAttendanceReportProps> = ({ onClose }) => {
  const { users, branches, coachAttendanceRecords } = useData();
  const { t, language } = useLocalization();

  const getToday = () => new Date().toISOString().split('T')[0];

  const getWeekStart = () => {
    const now = new Date();
    const day = now.getDay();
    const diff = now.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    return new Date(now.setDate(diff)).toISOString().split('T')[0];
  };
  
  const getMonthStart = () => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
  };

  const [startDate, setStartDate] = useState(getMonthStart());
  const [endDate, setEndDate] = useState(getToday());

  const datesInRange = useMemo(() => {
    const dates = [];
     if (!startDate || !endDate || new Date(startDate) > new Date(endDate)) {
        return [];
    }
    
    // Use UTC to avoid timezone issues
    let currentDate = new Date(startDate + 'T00:00:00Z');
    const lastDate = new Date(endDate + 'T00:00:00Z');

    while (currentDate <= lastDate) {
      dates.push(currentDate.toISOString().split('T')[0]);
      currentDate.setUTCDate(currentDate.getUTCDate() + 1);
    }
    return dates;
  }, [startDate, endDate]);

  const reportData = useMemo(() => {
    const coaches = users.filter(u => u.role === Role.Coach);
    return coaches.map(coach => {
      const coachAttendance = coachAttendanceRecords.filter(
        r => {
            const recordDate = new Date(r.date);
            return r.coachId === coach.id && recordDate >= new Date(startDate) && recordDate <= new Date(endDate);
        }
      );
      const branch = branches.find(b => b.id === coach.branchId);
      return {
        ...coach,
        branchName: branch ? t(branch.name as keyof typeof translations.en) : t('notAssigned'),
        attendance: datesInRange.map(date => 
          coachAttendance.some(r => r.date === date)
        ),
        totalAttended: coachAttendance.length,
      };
    }).sort((a, b) => a.username.localeCompare(b.username));
  }, [users, coachAttendanceRecords, datesInRange, startDate, endDate, branches, t]);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00Z');
    return date.toLocaleDateString(language, { timeZone: 'UTC', month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-brand-dark text-white p-4 md:p-8">
      <div className="max-w-full mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold font-display text-brand-lime">{t('coachAttendanceReport')}</h1>
          <button onClick={onClose} className="bg-gray-600 text-white font-bold py-2 px-4 rounded hover:bg-gray-500 transition-colors">
            &times; {t('closeReport')}
          </button>
        </div>

        <div className="bg-brand-gray p-6 rounded-lg shadow-lg mb-6 flex flex-wrap items-end gap-4">
          <div>
            <label className="block text-gray-300 mb-2">{t('startDate')}</label>
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" />
          </div>
          <div>
            <label className="block text-gray-300 mb-2">{t('endDate')}</label>
            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setStartDate(getToday()); setEndDate(getToday()); }} className="bg-brand-light-gray text-white py-2 px-4 rounded hover:bg-gray-500">{t('today')}</button>
            <button onClick={() => { setStartDate(getWeekStart()); setEndDate(getToday()); }} className="bg-brand-light-gray text-white py-2 px-4 rounded hover:bg-gray-500">{t('thisWeek')}</button>
            <button onClick={() => { setStartDate(getMonthStart()); setEndDate(getToday()); }} className="bg-brand-light-gray text-white py-2 px-4 rounded hover:bg-gray-500">{t('thisMonth')}</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full bg-brand-gray rounded-lg shadow-lg border-separate border-spacing-0">
            <thead className="border-b-2 border-brand-light-gray">
              <tr>
                <th className="sticky left-0 bg-brand-gray p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider z-10">{t('username')}</th>
                <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('assignedBranch')}</th>
                {datesInRange.map(date => (
                  <th key={date} className="p-4 text-center text-sm font-bold text-gray-300 uppercase tracking-wider whitespace-nowrap">{formatDate(date)}</th>
                ))}
                <th className="sticky right-0 bg-brand-gray p-4 text-right text-sm font-bold text-gray-300 uppercase tracking-wider z-10">{t('totalAttended')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-light-gray">
              {reportData.map(coach => (
                <tr key={coach.id} className="hover:bg-brand-light-gray/50 transition-colors">
                  <td className="sticky left-0 bg-brand-gray hover:bg-brand-light-gray/50 p-4 whitespace-nowrap text-white z-10">{coach.username}</td>
                  <td className="p-4 whitespace-nowrap text-gray-300">{coach.branchName}</td>
                  {coach.attendance.map((attended, index) => (
                    <td key={index} className="p-4 whitespace-nowrap text-center">
                      {attended ? (
                        <span title={t('present')} className="text-green-400 text-2xl">✓</span>
                      ) : (
                        <span title={t('absent')} className="text-red-400 text-2xl">✗</span>
                      )}
                    </td>
                  ))}
                  <td className="sticky right-0 bg-brand-gray hover:bg-brand-light-gray/50 p-4 whitespace-nowrap text-right font-bold text-brand-lime z-10">{coach.totalAttended}</td>
                </tr>
              ))}
            </tbody>
          </table>
           {reportData.length === 0 && <p className="text-center text-gray-400 py-8">No coaches found.</p>}
        </div>
      </div>
    </div>
  );
};

export default CoachAttendanceReport;
