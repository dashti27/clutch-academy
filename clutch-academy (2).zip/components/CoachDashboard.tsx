
import React, { useMemo, useState } from 'react';
import { Subscriber, Role } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import Header from './Header';
import SubscriberList from './SubscriberList';
// FIX: Import 'translations' to be used for type casting branch names for localization.
import { translations } from '../lib/localization';

const CoachDashboard: React.FC = () => {
    const { currentUser } = useAuth();
    const { branches, subscribers } = useData();
    const { t } = useLocalization();
    const today = new Date().toISOString().split('T')[0];
    const [searchQuery, setSearchQuery] = useState('');

    const coachBranch = useMemo(() => {
        return branches.find(b => b.id === currentUser?.branchId);
    }, [branches, currentUser]);

    const branchSubscribers = useMemo(() => {
        const byBranch = subscribers.filter(s => s.branchId === currentUser?.branchId);
        if (!searchQuery) {
            return byBranch;
        }
        return byBranch.filter(s => 
            s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
            s.phone.includes(searchQuery)
        );
    }, [subscribers, currentUser, searchQuery]);

    const handleEditSubscriber = (subscriber: Subscriber) => {
        // Coaches cannot edit subscribers, so this is a no-op
    };

    if (!currentUser || !coachBranch) {
        return <div className="min-h-screen bg-brand-dark flex items-center justify-center text-white">Loading coach data...</div>;
    }

    const dashboardTitle = `${t('coachDashboard')} - ${t(coachBranch.name as keyof typeof translations.en)}`;

    return (
        <div className="min-h-screen bg-brand-dark text-white">
            <Header title={dashboardTitle} />
            <main className="p-4 md:p-8">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold font-display text-brand-lime">{t('subscribers')}</h2>
                    <input
                        type="text"
                        placeholder={t('searchByNameOrPhone')}
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className="bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime"
                    />
                </div>
                <SubscriberList 
                    subscribers={branchSubscribers} 
                    currentUserRole={Role.Coach} 
                    onEdit={handleEditSubscriber}
                    attendanceDate={today}
                />
            </main>
        </div>
    );
};

export default CoachDashboard;
