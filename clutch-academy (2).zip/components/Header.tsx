import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLocalization } from '../contexts/LocalizationContext';

const Header: React.FC<{ title: string }> = ({ title }) => {
  const { logout } = useAuth();
  const { language, setLanguage, t } = useLocalization();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  return (
    <header className="bg-brand-gray p-4 shadow-lg flex items-center justify-between">
      <div className="flex items-center gap-4">
        <h1 className="text-2xl md:text-4xl text-white font-display tracking-wider uppercase">{title}</h1>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={toggleLanguage}
          className="text-white font-semibold py-2 px-4 rounded-md bg-brand-light-gray hover:bg-gray-500 transition-colors"
        >
          {language === 'en' ? 'العربية' : 'English'}
        </button>
        <button
          onClick={logout}
          className="text-brand-dark font-bold py-2 px-4 rounded-md bg-brand-lime hover:bg-lime-400 transition-colors"
        >
          {t('logout')}
        </button>
      </div>
    </header>
  );
};

export default Header;