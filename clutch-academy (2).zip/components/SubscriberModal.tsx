
import React, { useState, useEffect } from 'react';
import { Subscriber } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import { translations } from '../lib/localization';

interface SubscriberModalProps {
  isOpen: boolean;
  onClose: () => void;
  subscriberToEdit: Subscriber | null;
}

const SubscriberModal: React.FC<SubscriberModalProps> = ({ isOpen, onClose, subscriberToEdit }) => {
  const { branches, addSubscriber, updateSubscriber } = useData();
  const { t } = useLocalization();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [subscriptionEndDate, setSubscriptionEndDate] = useState('');
  const [branchId, setBranchId] = useState<string>('');

  useEffect(() => {
    if (subscriberToEdit) {
      setName(subscriberToEdit.name);
      setPhone(subscriberToEdit.phone);
      setSubscriptionEndDate(subscriberToEdit.subscriptionEndDate);
      setBranchId(subscriberToEdit.branchId || '');
    } else {
      setName('');
      setPhone('');
      setSubscriptionEndDate('');
      setBranchId('');
    }
  }, [subscriberToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !subscriptionEndDate || !branchId) return;

    if (subscriberToEdit) {
      updateSubscriber({ ...subscriberToEdit, name, phone, subscriptionEndDate, branchId: branchId });
    } else {
      addSubscriber({ name, phone, subscriptionEndDate, branchId: branchId });
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-brand-gray p-8 rounded-lg shadow-2xl w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-white mb-6">{subscriberToEdit ? t('editSubscriber') : t('addSubscriber')}</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-300 mb-2">{t('subscriberName')}</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
          <div className="mb-4">
            <label className="block text-gray-300 mb-2">{t('phone')}</label>
            <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
          <div className="mb-4">
            <label className="block text-gray-300 mb-2">{t('subscriptionEndDate')}</label>
            <input type="date" value={subscriptionEndDate} onChange={e => setSubscriptionEndDate(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
          <div className="mb-6">
            <label className="block text-gray-300 mb-2">{t('branchName')}</label>
            <select value={branchId} onChange={e => setBranchId(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required>
              <option value="" disabled>{t('selectBranch')}</option>
              {branches.map(branch => (
                <option key={branch.id} value={branch.id}>{t(branch.name as keyof typeof translations.en)}</option>
              ))}
            </select>
          </div>
          <div className="flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500">{t('cancel')}</button>
            <button type="submit" className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400">{t('save')}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SubscriberModal;