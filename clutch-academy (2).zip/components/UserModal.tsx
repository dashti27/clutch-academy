
import React, { useState, useEffect } from 'react';
import { User, Role } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import { translations } from '../lib/localization';

interface UserModalProps {
  isOpen: boolean;
  onClose: () => void;
  userToEdit: User | null;
}

const UserModal: React.FC<UserModalProps> = ({ isOpen, onClose, userToEdit }) => {
  const { branches, addUser, updateUser } = useData();
  const { t } = useLocalization();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>(Role.Coach);
  const [branchId, setBranchId] = useState<string>('');

  useEffect(() => {
    if (userToEdit) {
      setUsername(userToEdit.username);
      setPassword(userToEdit.password);
      setRole(userToEdit.role);
      setBranchId(userToEdit.branchId || '');
    } else {
      setUsername('');
      setPassword('');
      setRole(Role.Coach);
      setBranchId('');
    }
  }, [userToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;

    const userData = {
        username,
        password,
        role,
        branchId: role === Role.Coach && branchId ? branchId : undefined,
    };

    if (userToEdit) {
      updateUser({ ...userData, id: userToEdit.id });
    } else {
      addUser(userData);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-brand-gray p-8 rounded-lg shadow-2xl w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-white mb-6">{userToEdit ? t('editUser') : t('addUser')}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-300 mb-2">{t('username')}</label>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
          <div>
            <label className="block text-gray-300 mb-2">{t('password')}</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required />
          </div>
           <div>
            <label className="block text-gray-300 mb-2">{t('role')}</label>
            <select value={role} onChange={e => setRole(Number(e.target.value) as Role)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime" required>
                <option value={Role.Admin}>{t('admin')}</option>
                <option value={Role.Coach}>{t('coach')}</option>
            </select>
          </div>
          {role === Role.Coach && (
            <div>
              <label className="block text-gray-300 mb-2">{t('assignedBranch')}</label>
              <select value={branchId} onChange={e => setBranchId(e.target.value)} className="w-full bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime">
                <option value="">{t('notAssigned')}</option>
                {branches.map(branch => (
                  <option key={branch.id} value={branch.id}>{t(branch.name as keyof typeof translations.en)}</option>
                ))}
              </select>
            </div>
          )}
          <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500">{t('cancel')}</button>
            <button type="submit" className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400">{t('save')}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserModal;
