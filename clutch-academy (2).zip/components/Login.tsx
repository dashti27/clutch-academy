
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLocalization } from '../contexts/LocalizationContext';
import CreateAccountModal from './CreateAccountModal';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const { t } = useLocalization();
  const [isCreateAccountModalOpen, setCreateAccountModalOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(username, password);
    if (!success) {
      setError(t('invalidCredentials'));
    }
  };

  return (
    <>
      <div className="min-h-screen bg-brand-dark flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
              <h2 className="text-5xl font-display text-brand-lime tracking-widest uppercase">Clutch Academy</h2>
          </div>
          <div className="bg-brand-gray p-8 rounded-lg shadow-2xl">
            <h1 className="text-3xl text-white font-display text-center mb-6">{t('loginTitle')}</h1>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-gray-300 text-sm font-bold mb-2" htmlFor="username">
                  {t('username')}
                </label>
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-brand-light-gray text-white rounded py-2 px-3 leading-tight focus:outline-none focus:ring-2 focus:ring-brand-lime"
                  required
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-300 text-sm font-bold mb-2" htmlFor="password">
                  {t('password')}
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-brand-light-gray text-white rounded py-2 px-3 leading-tight focus:outline-none focus:ring-2 focus:ring-brand-lime"
                  required
                />
              </div>
              {error && <p className="text-red-500 text-xs italic mb-4 text-center">{error}</p>}
              <div className="flex flex-col items-center justify-between gap-4">
                <button
                  type="submit"
                  className="w-full bg-brand-lime hover:bg-lime-400 text-brand-dark font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-colors duration-300"
                >
                  {t('login')}
                </button>
                <button
                  type="button"
                  onClick={() => setCreateAccountModalOpen(true)}
                  className="w-full text-brand-lime font-semibold py-2 px-4 rounded border border-brand-lime hover:bg-brand-lime/10 transition-colors"
                >
                  {t('createAccount')}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <CreateAccountModal isOpen={isCreateAccountModalOpen} onClose={() => setCreateAccountModalOpen(false)} />
    </>
  );
};

export default Login;
