
import React, { useState, useMemo } from 'react';
import { Branch, Subscriber, Role, User } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import { useAuth } from '../contexts/AuthContext';
import Header from './Header';
import SubscriberList from './SubscriberList';
import SubscriberModal from './SubscriberModal';
import BranchModal from './BranchModal';
import UserModal from './UserModal';
import AttendanceReport from './AttendanceReport';
import CoachAttendanceReport from './CoachAttendanceReport';
import ToggleSwitch from './ToggleSwitch';
// FIX: Import 'translations' to be used for type casting branch names for localization.
import { translations } from '../lib/localization';

const AdminDashboard: React.FC = () => {
  const { branches, subscribers, users, deleteUser, deleteBranch, coachAttendanceRecords, toggleCoachAttendance } = useData();
  const { t } = useLocalization();
  const { currentUser } = useAuth();
  
  const [selectedBranchId, setSelectedBranchId] = useState<string | null>(null);
  const [attendanceDate, setAttendanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [showReport, setShowReport] = useState(false);
  const [showCoachReport, setShowCoachReport] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [isSubscriberModalOpen, setSubscriberModalOpen] = useState(false);
  const [subscriberToEdit, setSubscriberToEdit] = useState<Subscriber | null>(null);
  
  const [isBranchModalOpen, setBranchModalOpen] = useState(false);
  const [branchToEdit, setBranchToEdit] = useState<Branch | null>(null);
  
  const [isUserModalOpen, setUserModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<User | null>(null);
  
  const filteredSubscribers = useMemo(() => {
    const byBranch = selectedBranchId ? subscribers.filter(s => s.branchId === selectedBranchId) : subscribers;
    if (!searchQuery) {
        return byBranch;
    }
    return byBranch.filter(s => 
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        s.phone.includes(searchQuery)
    );
  }, [subscribers, selectedBranchId, searchQuery]);

  const coaches = useMemo(() => users.filter(u => u.role === Role.Coach), [users]);

  const handleEditSubscriber = (subscriber: Subscriber) => {
    setSubscriberToEdit(subscriber);
    setSubscriberModalOpen(true);
  };
  
  const handleAddSubscriber = () => {
    setSubscriberToEdit(null);
    setSubscriberModalOpen(true);
  };

  const handleEditBranch = (branch: Branch) => {
    setBranchToEdit(branch);
    setBranchModalOpen(true);
  };

  const handleDeleteBranch = (branchId: string) => {
    if (window.confirm(t('confirmDelete'))) {
        deleteBranch(branchId);
    }
  };
  
  const handleAddBranch = () => {
    setBranchToEdit(null);
    setBranchModalOpen(true);
  };
  
  const handleEditUser = (user: User) => {
    setUserToEdit(user);
    setUserModalOpen(true);
  };

  const handleAddUser = () => {
    setUserToEdit(null);
    setUserModalOpen(true);
  };

  const getBranchName = (branchId?: string) => {
    if (!branchId) return t('notAssigned');
    const branch = branches.find(b => b.id === branchId);
    return branch ? t(branch.name as keyof typeof translations.en) : t('notAssigned');
  };

  const isCoachAttended = (coachId: string): boolean => {
    return coachAttendanceRecords.some(
        r => r.coachId === coachId && r.date === attendanceDate
    );
  };
  
  if (showReport) {
    return <AttendanceReport onClose={() => setShowReport(false)} />;
  }
  if (showCoachReport) {
    return <CoachAttendanceReport onClose={() => setShowCoachReport(false)} />;
  }

  return (
    <div className="min-h-screen bg-brand-dark text-white">
      <Header title={t('adminDashboard')} />
      <main className="p-4 md:p-8 space-y-12">
        <div>
            <h2 className="text-3xl font-bold font-display text-brand-lime mb-4">{t('branches')}</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                <button onClick={() => setSelectedBranchId(null)} className={`p-4 rounded-lg text-center font-bold transition-all ${!selectedBranchId ? 'bg-brand-lime text-brand-dark ring-2 ring-lime-300' : 'bg-brand-gray hover:bg-brand-light-gray'}`}>
                    {t('allBranches')}
                </button>
                {branches.map(branch => (
                    <div key={branch.id} className="relative group">
                        <button onClick={() => setSelectedBranchId(branch.id)} className={`w-full h-full p-4 rounded-lg text-center font-bold transition-all ${selectedBranchId === branch.id ? 'bg-brand-lime text-brand-dark ring-2 ring-lime-300' : 'bg-brand-gray hover:bg-brand-light-gray'}`}>
                            {t(branch.name as keyof typeof translations.en)}
                        </button>
                         <div className="absolute top-1 right-1 flex opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleEditBranch(branch)} className="text-gray-400 hover:text-white p-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L14.732 3.732z" /></svg>
                            </button>
                            <button onClick={() => handleDeleteBranch(branch.id)} className="text-gray-400 hover:text-red-400 p-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                         </div>
                    </div>
                ))}
                 <button onClick={handleAddBranch} className="p-4 rounded-lg text-center font-bold transition-all bg-transparent border-2 border-dashed border-brand-light-gray text-brand-light-gray hover:bg-brand-gray hover:text-white">
                    + {t('addBranch')}
                </button>
            </div>
        </div>

        <div>
            <div className="flex flex-wrap justify-between items-center gap-4 mb-4">
                <h2 className="text-3xl font-bold font-display text-brand-lime">{t('subscribers')}</h2>
                <div className="flex flex-wrap items-center gap-4">
                    <input
                        type="text"
                        placeholder={t('searchByNameOrPhone')}
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className="bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime"
                    />
                    <div className="flex items-center gap-2">
                        <label htmlFor="attendance-date" className="text-gray-300 font-semibold">{t('attendanceDate')}:</label>
                        <input
                            id="attendance-date"
                            type="date"
                            value={attendanceDate}
                            onChange={e => setAttendanceDate(e.target.value)}
                            className="bg-brand-light-gray text-white p-2 rounded focus:outline-none focus:ring-2 focus:ring-brand-lime"
                        />
                    </div>
                    <button onClick={() => setShowReport(true)} className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-400 transition-colors">
                      {t('viewReport')}
                    </button>
                    <button onClick={handleAddSubscriber} className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400 transition-colors">
                        {t('addSubscriber')}
                    </button>
                </div>
            </div>
            <SubscriberList subscribers={filteredSubscribers} currentUserRole={Role.Admin} onEdit={handleEditSubscriber} attendanceDate={attendanceDate} />
        </div>

        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-3xl font-bold font-display text-brand-lime">{t('coaches')}</h2>
                <button onClick={() => setShowCoachReport(true)} className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-400 transition-colors">
                    {t('viewCoachReport')}
                </button>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-brand-gray rounded-lg shadow-lg">
                <thead className="border-b-2 border-brand-light-gray">
                  <tr>
                    <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('username')}</th>
                    <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('assignedBranch')}</th>
                    <th className="p-4 text-center text-sm font-bold text-gray-300 uppercase tracking-wider">{t('attendance')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-light-gray">
                    {coaches.map(coach => (
                        <tr key={coach.id} className="hover:bg-brand-light-gray/50 transition-colors">
                            <td className="p-4 whitespace-nowrap text-white">{coach.username}</td>
                            <td className="p-4 whitespace-nowrap text-gray-300">{getBranchName(coach.branchId)}</td>
                            <td className="p-4 whitespace-nowrap text-center">
                                <ToggleSwitch
                                    checked={isCoachAttended(coach.id)}
                                    onChange={() => toggleCoachAttendance(coach.id, attendanceDate)}
                                />
                            </td>
                        </tr>
                    ))}
                </tbody>
              </table>
            </div>
        </div>

        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-3xl font-bold font-display text-brand-lime">{t('userManagement')}</h2>
                <button onClick={handleAddUser} className="bg-brand-lime text-brand-dark font-bold py-2 px-4 rounded hover:bg-lime-400 transition-colors">
                    {t('addUser')}
                </button>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-brand-gray rounded-lg shadow-lg">
                <thead className="border-b-2 border-brand-light-gray">
                  <tr>
                    <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('username')}</th>
                    <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('role')}</th>
                    <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('assignedBranch')}</th>
                    <th className="p-4 text-right text-sm font-bold text-gray-300 uppercase tracking-wider">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-light-gray">
                    {users.map(user => (
                        <tr key={user.id} className="hover:bg-brand-light-gray/50 transition-colors">
                            <td className="p-4 whitespace-nowrap text-white">{user.username}</td>
                            <td className="p-4 whitespace-nowrap text-gray-300">{user.role === Role.Admin ? t('admin') : t('coach')}</td>
                            <td className="p-4 whitespace-nowrap text-gray-300">{user.role === Role.Admin ? '-' : getBranchName(user.branchId)}</td>
                            <td className="p-4 whitespace-nowrap text-right space-x-2">
                                <button onClick={() => handleEditUser(user)} className="text-blue-400 hover:text-blue-300 font-semibold">{t('editUser')}</button>
                                <button 
                                    onClick={() => deleteUser(user.id)} 
                                    className="text-red-400 hover:text-red-300 font-semibold disabled:text-gray-500 disabled:cursor-not-allowed"
                                    disabled={user.id === currentUser?.id}
                                >
                                    {t('delete')}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
              </table>
            </div>
        </div>

      </main>
      <SubscriberModal isOpen={isSubscriberModalOpen} onClose={() => setSubscriberModalOpen(false)} subscriberToEdit={subscriberToEdit} />
      <BranchModal isOpen={isBranchModalOpen} onClose={() => setBranchModalOpen(false)} branchToEdit={branchToEdit} />
      <UserModal isOpen={isUserModalOpen} onClose={() => setUserModalOpen(false)} userToEdit={userToEdit} />
    </div>
  );
};

export default AdminDashboard;
