
import React from 'react';
import { Subscriber, Role } from '../types';
import { useData } from '../contexts/DataContext';
import { useLocalization } from '../contexts/LocalizationContext';
import ToggleSwitch from './ToggleSwitch';

interface SubscriberListProps {
  subscribers: Subscriber[];
  currentUserRole: Role;
  onEdit: (subscriber: Subscriber) => void;
  attendanceDate: string;
}

const SubscriberList: React.FC<SubscriberListProps> = ({ subscribers, currentUserRole, onEdit, attendanceDate }) => {
  const { deleteSubscriber, toggleAttendance, attendanceRecords } = useData();
  const { t } = useLocalization();

  const getStatus = (endDate: string) => {
    const today = new Date();
    today.setHours(0,0,0,0);
    return new Date(endDate) >= today ? 'Active' : 'Expired';
  };

  const isAttended = (subscriberId: string): boolean => {
    return attendanceRecords.some(
      r => r.subscriberId === subscriberId && r.date === attendanceDate
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-brand-gray rounded-lg shadow-lg">
        <thead className="border-b-2 border-brand-light-gray">
          <tr>
            <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('name')}</th>
            <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('phone')}</th>
            <th className="p-4 text-left text-sm font-bold text-gray-300 uppercase tracking-wider">{t('subscriptionStatus')}</th>
            <th className="p-4 text-center text-sm font-bold text-gray-300 uppercase tracking-wider">{t('attendance')}</th>
            {currentUserRole === Role.Admin && <th className="p-4 text-right text-sm font-bold text-gray-300 uppercase tracking-wider">{t('actions')}</th>}
          </tr>
        </thead>
        <tbody className="divide-y divide-brand-light-gray">
          {subscribers.map(subscriber => {
            const status = getStatus(subscriber.subscriptionEndDate);
            return (
              <tr key={subscriber.id} className="hover:bg-brand-light-gray/50 transition-colors">
                <td className="p-4 whitespace-nowrap text-white">{subscriber.name}</td>
                <td className="p-4 whitespace-nowrap text-gray-300">{subscriber.phone}</td>
                <td className="p-4 whitespace-nowrap">
                  <span className={`px-3 py-1 text-xs font-bold rounded-full ${status === 'Active' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                    {status === 'Active' ? t('active') : t('expired')}
                  </span>
                </td>
                <td className="p-4 whitespace-nowrap text-center">
                    <ToggleSwitch checked={isAttended(subscriber.id)} onChange={() => toggleAttendance(subscriber.id, attendanceDate)} />
                </td>
                {currentUserRole === Role.Admin && (
                  <td className="p-4 whitespace-nowrap text-right space-x-2">
                    <button onClick={() => onEdit(subscriber)} className="text-blue-400 hover:text-blue-300 font-semibold">{t('editSubscriber')}</button>
                    <button onClick={() => deleteSubscriber(subscriber.id)} className="text-red-400 hover:text-red-300 font-semibold">{t('delete')}</button>
                  </td>
                )}
              </tr>
            )
          })}
        </tbody>
      </table>
      {subscribers.length === 0 && <p className="text-center text-gray-400 py-8">{t('subscribers')} not found.</p>}
    </div>
  );
};

export default SubscriberList;
