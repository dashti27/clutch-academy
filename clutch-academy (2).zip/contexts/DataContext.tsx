// FIX: Implemented the DataContext to provide and manage application data.
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { Branch, Subscriber, User, Role, AttendanceRecord, CoachAttendanceRecord } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Initial Data
const initialBranches: Branch[] = [
  { id: '1', name: 'Mansouriya' },
  { id: '2', name: 'Abu Halifa' },
  { id: '3', name: 'Dasman' },
  { id: '4', name: 'Sabah AlSalem' },
  { id: '5', name: 'Mansouriya Kids' },
  { id: '6', name: 'Mansouriya Mid' },
];

const initialUsers: User[] = [
  { id: 'u1', username: 'admin', password: 'password', role: Role.Admin },
  { id: 'u2', username: 'coach1', password: 'password', role: Role.Coach, branchId: '1' },
  { id: 'u3', username: 'coach2', password: 'password', role: Role.Coach, branchId: '2' },
];

const initialSubscribers: Subscriber[] = [
    { id: 's1', name: 'John Doe', phone: '12345678', subscriptionEndDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split('T')[0], branchId: '1' },
    { id: 's2', name: 'Jane Smith', phone: '87654321', subscriptionEndDate: new Date(new Date().setDate(new Date().getDate() - 10)).toISOString().split('T')[0], branchId: '1' },
    { id: 's3', name: 'Peter Jones', phone: '11223344', subscriptionEndDate: new Date(new Date().setDate(new Date().getDate() + 60)).toISOString().split('T')[0], branchId: '2' },
    { id: 's4', name: 'Mary Williams', phone: '44332211', subscriptionEndDate: new Date(new Date().setDate(new Date().getDate() + 90)).toISOString().split('T')[0], branchId: '3' },
];

const initialAttendance: AttendanceRecord[] = [
    { id: 'a1', subscriberId: 's2', date: new Date().toISOString().split('T')[0] },
    { id: 'a2', subscriberId: 's4', date: new Date().toISOString().split('T')[0] },
    { id: 'a3', subscriberId: 's1', date: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().split('T')[0] },
    { id: 'a4', subscriberId: 's2', date: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().split('T')[0] },
    { id: 'a5', subscriberId: 's3', date: new Date(new Date().setDate(new Date().getDate() - 2)).toISOString().split('T')[0] },
];

const initialCoachAttendance: CoachAttendanceRecord[] = [
    { id: 'ca1', coachId: 'u2', date: new Date().toISOString().split('T')[0] },
    { id: 'ca2', coachId: 'u3', date: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().split('T')[0] },
]


interface DataContextType {
  branches: Branch[];
  subscribers: Subscriber[];
  users: User[];
  attendanceRecords: AttendanceRecord[];
  coachAttendanceRecords: CoachAttendanceRecord[];
  addBranch: (branch: Omit<Branch, 'id'>) => void;
  updateBranch: (branch: Branch) => void;
  deleteBranch: (branchId: string) => void;
  addSubscriber: (subscriber: Omit<Subscriber, 'id'>) => void;
  updateSubscriber: (subscriber: Subscriber) => void;
  deleteSubscriber: (subscriberId: string) => void;
  toggleAttendance: (subscriberId: string, date: string) => void;
  toggleCoachAttendance: (coachId: string, date: string) => void;
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (user: User) => void;
  deleteUser: (userId: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [branches, setBranches] = useState<Branch[]>(initialBranches);
  const [subscribers, setSubscribers] = useState<Subscriber[]>(initialSubscribers);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(initialAttendance);
  const [coachAttendanceRecords, setCoachAttendanceRecords] = useState<CoachAttendanceRecord[]>(initialCoachAttendance);

  const addBranch = (branch: Omit<Branch, 'id'>) => {
    const newBranch = { ...branch, id: uuidv4() };
    setBranches(prev => [...prev, newBranch]);
  };

  const updateBranch = (updatedBranch: Branch) => {
    setBranches(prev => prev.map(b => b.id === updatedBranch.id ? updatedBranch : b));
  };

  const deleteBranch = (branchId: string) => {
    setBranches(prev => prev.filter(b => b.id !== branchId));
    setUsers(prev => prev.map(u => u.branchId === branchId ? { ...u, branchId: undefined } : u));
    setSubscribers(prev => prev.map(s => s.branchId === branchId ? { ...s, branchId: undefined } : s));
  };

  const addSubscriber = (subscriber: Omit<Subscriber, 'id'>) => {
    setSubscribers(prev => [...prev, { ...subscriber, id: uuidv4() }]);
  };

  const updateSubscriber = (updatedSubscriber: Subscriber) => {
    setSubscribers(prev => prev.map(s => s.id === updatedSubscriber.id ? updatedSubscriber : s));
  };
  
  const deleteSubscriber = (subscriberId: string) => {
    setSubscribers(prev => prev.filter(s => s.id !== subscriberId));
    setAttendanceRecords(prev => prev.filter(ar => ar.subscriberId !== subscriberId));
  };

  const toggleAttendance = (subscriberId: string, date: string) => {
    setAttendanceRecords(prev => {
      const existingRecord = prev.find(
        r => r.subscriberId === subscriberId && r.date === date
      );
      if (existingRecord) {
        return prev.filter(r => r.id !== existingRecord.id);
      } else {
        return [...prev, { id: uuidv4(), subscriberId, date }];
      }
    });
  };

  const toggleCoachAttendance = (coachId: string, date: string) => {
    setCoachAttendanceRecords(prev => {
        const existingRecord = prev.find(
            r => r.coachId === coachId && r.date === date
        );
        if (existingRecord) {
            return prev.filter(r => r.id !== existingRecord.id);
        } else {
            return [...prev, { id: uuidv4(), coachId, date }];
        }
    });
  };

  const addUser = (user: Omit<User, 'id'>) => {
    setUsers(prev => [...prev, { ...user, id: uuidv4() }]);
  };

  const updateUser = (updatedUser: User) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
  };

  const deleteUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;
    setUsers(prev => prev.filter(u => u.id !== userId));
    if (user.role === Role.Coach) {
        setCoachAttendanceRecords(prev => prev.filter(car => car.coachId !== userId));
    }
  };

  return (
    <DataContext.Provider value={{
      branches,
      subscribers,
      users,
      attendanceRecords,
      coachAttendanceRecords,
      addBranch,
      updateBranch,
      deleteBranch,
      addSubscriber,
      updateSubscriber,
      deleteSubscriber,
      toggleAttendance,
      toggleCoachAttendance,
      addUser,
      updateUser,
      deleteUser
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};